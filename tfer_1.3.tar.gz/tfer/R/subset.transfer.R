"[.transfer" = function(tferObj, i){
  return(tferObj$results[i])
}